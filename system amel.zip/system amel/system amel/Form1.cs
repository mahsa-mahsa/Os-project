﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using System.Timers;
using System.Windows.Threading;

namespace system_amel
{
    public partial class Form1 : Form
    {
        DispatcherTimer timer = new DispatcherTimer();
        Queue<process> ready = new Queue<process>(10);
       Queue<process> block1 = new Queue<process>();
       Queue<process> suspend1 = new Queue<process>();
       Queue<process> finish1 = new Queue<process>();
       Queue<process> list = new Queue<process>();

       
        public Form1()
        {
            

            InitializeComponent();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (ready.Count < 10)
            {
                process p = new process();

                p.name = textBox1.Text;
                Random r = new Random();
                p.io_time = r.Next(1, 5);
                p.state = "ready";
                 p.id = process.counter++;
                ready.Enqueue(p);
                list.Enqueue(p);
                listBox1.Items.Add(p.name);
               
            }
            else
            {
                MessageBox.Show("not enough space in ready");
            }
            textBox1.Text = "";
          
        }

     
        private void timer1_Tick(object sender, EventArgs e)
        {
           
            process pp = new process();
            process k= new process();

            if (textBox3.Text == "")
            {
                if (ready.Count != 0)
                {
                    pp = ready.Dequeue();
                    ready = new Queue<process>(ready.Where(p => p != pp));

                    for (int i = 0; i < listBox1.Items.Count; i++)
                    {
                        if (listBox1.Items[i].ToString() == pp.name)
                        {
                            listBox1.Items.Remove(pp.name);
                            i--;
                        }
                    }

                }
                pp.state = "runing";
                textBox3.Text = pp.name;
                pp.time = pp.time + 1;



            }

            else
            {

                if (list.Count > 1)
                {

                    Random rr = new Random();
                    int h = rr.Next(10);
                    if (h == 1)
                    {

                        pp.name = textBox3.Text;
                        for (int i = 0; i < list.Count(); i++)
                        {
                            if (list.ToArray()[i].name == pp.name)
                            {
                                pp = list.ToArray()[i];
                                pp.state = "runing";
                            }
                        }


                        k = pp;
                        k.state = "block";

                        block1.Enqueue(k);
                        if (ready.Count != 0)
                        {
                            pp = ready.Dequeue();
                            for (int i = 0; i < listBox1.Items.Count; i++)
                            {
                                if (listBox1.Items[i].ToString() == pp.name)
                                {
                                    listBox1.Items.Remove(pp.name);
                                    i--;
                                }
                            }


                            pp.state = "runing";
                            textBox3.Text = pp.name;
                            pp.time = pp.time + 1;
                            block.Items.Add(k.name);

                        }
                        else
                        {
                            textBox3.Text = "";
                            block.Items.Add(k.name);
                        }

                    }
                    else
                    {

                        pp.name = textBox3.Text;
                        for (int i = 0; i < list.Count(); i++)
                        {
                            if (list.ToArray()[i].name == pp.name)
                            {
                                pp = list.ToArray()[i];
                                pp.state = "runing";
                            }
                        }

                        if (ready.Count < 10)
                        {

                            k = pp;
                            if (ready.Count != 0)
                            {
                                pp = ready.Dequeue();

                                for (int i = 0; i < listBox1.Items.Count; i++)
                                {
                                    if (listBox1.Items[i].ToString() == pp.name)
                                    {
                                        listBox1.Items.Remove(pp.name);
                                        i--;
                                    }
                                }
                                pp.state = "runing";
                                textBox3.Text = pp.name;
                                pp.time = pp.time + 1;
                                k.state = "ready";
                                ready.Enqueue(k);
                                listBox1.Items.Add(k.name);


                            }
                            

                        }
                        else if(ready.Count>=10)
                        {
                            k=pp;
                            if (ready.Count != 0)
                            {
                                pp = ready.Dequeue();

                                for (int i = 0; i < listBox1.Items.Count; i++)
                                {
                                    if (listBox1.Items[i].ToString() == pp.name)
                                    {
                                        listBox1.Items.Remove(pp.name);
                                        i--;
                                    }
                                }
                                pp.state = "runing";
                                textBox3.Text = pp.name;
                                pp.time = pp.time + 1;
                                ////
                                k.state = "suspend";
                                suspend1.Enqueue(k);
                                suspend.Items.Add(k.name);

                            }


                        }








                    }

                }
                else

                {
                    if(list.Count==1)
                    {
                    Random rr = new Random();
                    int h = rr.Next(10);
                    if (h == 1)
                    {

                        pp.name = textBox3.Text;
                        for (int i = 0; i < list.Count(); i++)
                        {
                            if (list.ToArray()[i].name == pp.name)
                            {
                                pp = list.ToArray()[i];
                                pp.state = "runing";
                            }
                        }


                        
                        pp.state = "block";

                        block1.Enqueue(pp);
                        textBox3.Text = "";
                       block.Items.Add(pp.name);
                       
                    }
                }

                }
            }

           
            for (int i = 0; i < block1.Count(); i++)
            {
               
                 if (block1.Count != 0 && block1.ToArray()[i].block_time < block1.ToArray()[i].io_time)
                    {
                        block1.ToArray()[i].block_time = block1.ToArray()[i].block_time + 1;
                        if (block1.ToArray()[i].block_time >= 2)
                        {
                            block1.ToArray()[i].suspend_time = block1.ToArray()[i].io_time - 2;

                            
                          
                            if(block1.Count!=0)
                            {
                                pp = block1.ToArray()[i];
                                block1 = new Queue<process>(block1.Where(p => p != pp));
                                pp.state = "suspend";
                                suspend1.Enqueue(pp);
                                for (int ii = 0; ii < block.Items.Count; ii++)
                                {
                                    if (block.Items[ii].ToString() == pp.name)
                                    {
                                        block.Items.Remove(pp.name);
                                        ii--;
                                    }
                                }
                                suspend.Items.Add(pp.name);


                            }
                        }
                    }

                    else if (block1.Count != 0 && block1.ToArray()[i].block_time == block1.ToArray()[i].io_time)
                        {
                            
                            if(block1.Count!=0)
                            {
                               
                                if (ready.Count < 10)
                                {
                                    pp = block1.ToArray()[i];
                                    block1 = new Queue<process>(block1.Where(p => p != pp));
                                    pp.state = "ready";
                                    pp.block_time = 0;
                                    ready.Enqueue(pp);
                                    for (int ii = 0; ii < block.Items.Count; ii++)
                                    {
                                        if (block.Items[ii].ToString() == pp.name)
                                        {
                                            block.Items.Remove(pp.name);
                                            ii--;
                                        }
                                    }
                                    listBox1.Items.Add(pp.name);


                                }
                                else
                                {   pp = block1.ToArray()[i];
                                    block1 = new Queue<process>(block1.Where(p => p != pp));
                                
                                    pp.state = "suspend";
                                   suspend1.Enqueue(pp);
                                    for (int ii = 0; ii < block.Items.Count; ii++)
                                    {
                                        if (block.Items[ii].ToString() == pp.name)
                                        {
                                            block.Items.Remove(pp.name);
                                            ii--;
                                        }
                                    }
                                    suspend.Items.Add(pp.name);
                                }

                            }
                        }
                   

                }
            

            for (int i = 0; i < suspend1.Count(); i++)
            {
                if (suspend1.ToArray()[i].suspend_time > 0)
                {
                    suspend1.ToArray()[i].suspend_time = suspend1.ToArray()[i].suspend_time - 1;
                    if (suspend1.ToArray()[i].suspend_time == 0)
                    {
                       
                       
                            if(suspend1.Count!=0)
                            {
                                pp = suspend1.ToArray()[i];
                                if (ready.Count < 10)
                                {
                                    suspend1 = new Queue<process>(suspend1.Where(p => p != pp));

                                    pp.state = "ready";
                                    pp.block_time = 0;
                                    ready.Enqueue(pp);
                                    for (int ii = 0; ii < suspend.Items.Count; ii++)
                                    {
                                        if (suspend.Items[ii].ToString() == pp.name)
                                        {
                                            suspend.Items.Remove(pp.name);
                                            ii--;
                                        }
                                    }
                                    listBox1.Items.Add(pp.name);
                                }
                             
                            

                        }
                    }
                }
                else if (suspend1.ToArray()[i].suspend_time == 0)
                {

                    if (suspend1.Count != 0)
                    {
                        pp = suspend1.ToArray()[i];
                        if (ready.Count < 10)
                        {
                            suspend1 = new Queue<process>(suspend1.Where(p => p != pp));
                            pp.state = "ready";
                            pp.block_time = 0;
                            ready.Enqueue(pp);
                            for (int ii = 0; ii < suspend.Items.Count; ii++)
                            {
                                if (suspend.Items[ii].ToString() == pp.name)
                                {
                                    suspend.Items.Remove(pp.name);
                                    ii--;
                                }
                            }
                            listBox1.Items.Add(pp.name);
                          
                        }
                    }

                }
               
            }
        }
       
        private void button5_Click(object sender, EventArgs e)
        {
            process p1=new process();
            process k1 = new process();
            process k2 = new process();
            for (int i = 0; i <ready.Count(); i++)
            {
                p1 = ready.ToArray()[i];

                if (p1.name!=null&&p1.id== int.Parse(textBox2.Text))
                {
                    p1.state = "finish";
                    finish1.Enqueue(p1);
                    ready = new Queue<process>(ready.Where(p => p != p1));
                    for (int ii = 0; ii< listBox1.Items.Count; ii++)
                    {
                        if (listBox1.Items[ii].ToString() == p1.name)
                        {
                            listBox1.Items.Remove(p1.name);
                            ii--;
                        }
                    }
                    finish.Items.Add(p1.name);
                    listBox2.Items.Add(p1.ToString());
                   list = new Queue<process>(list.Where(p => p != p1));


                }
                
            }
            for (int i = 0; i <block1.Count(); i++)
            {
                p1 = block1.ToArray()[i];

                if (p1.name!=null&&p1.id== int.Parse(textBox2.Text))
                {
                    p1.state = "finish";
                    finish1.Enqueue(p1);
                    block1 = new Queue<process>(block1.Where(p => p != p1));
                    for (int ii = 0; ii <block.Items.Count; ii++)
                    {
                        if (block.Items[ii].ToString() == p1.name)
                        {
                           block.Items.Remove(p1.name);
                            ii--;
                        }
                    }
                    finish.Items.Add(p1.name);
                    listBox2.Items.Add(p1.ToString());
                    list = new Queue<process>(list.Where(p => p != p1));

                }
             
            }
            for (int i = 0; i <suspend1.Count(); i++)
            {
                p1 = suspend1.ToArray()[i];

                if (p1.name!=null&&p1.id ==int.Parse( textBox2.Text))
                {
                    p1.state = "finish";
                    finish1.Enqueue(p1);
                    suspend1 = new Queue<process>(suspend1.Where(p => p != p1));
                    for (int ii = 0; ii < suspend.Items.Count; ii++)
                    {
                        if (suspend.Items[ii].ToString() == p1.name)
                        {
                            suspend.Items.Remove(p1.name);
                            ii--;
                        }
                    }
                    finish.Items.Add(p1.name);
                    listBox2.Items.Add(p1.ToString());
                    list = new Queue<process>(list.Where(p => p != p1));

                }
               
            }
        
            k1.name = textBox3.Text;
            for (int i = 0; i < list.Count;i++)
            {
                if (list.ToArray()[i].name ==k1.name)
                {
                    k1 = list.ToArray()[i];
                }


            }
            if(k1.name!=""&&k1.id==int.Parse(textBox2.Text))
            {
                k2 = k1;

                if (ready.Count != 0)
                {
                    k1= ready.Dequeue();

                    for (int i = 0; i < listBox1.Items.Count; i++)
                    {
                        if (listBox1.Items[i].ToString() == k1.name)
                        {
                            listBox1.Items.Remove(k1.name);
                            i--;
                        }
                    }
                   k1.state = "runing";
                    textBox3.Text =k1.name;
                    k1.time = k1.time + 1;
                    k2.state = "finish";
                    finish1.Enqueue(k2);
                    finish.Items.Add(k2.name);
                    listBox2.Items.Add(k2.ToString());
                    list = new Queue<process>(list.Where(p => p != k2));


                }
                else
                {
                    k1.state = "finish";
                    finish1.Enqueue(k1);
                    textBox3.Text = "";
                    finish.Items.Add(k1.name);
                    listBox2.Items.Add(k1.ToString());
                    list = new Queue<process>(list.Where(p => p != k1));

                }

            }
           

        }

       

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            timer1.Start();

        }
       
        
    }

}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace system_amel
{
    class process
    {
        public double time { get; set; }
        public double io_time { get; set; }
        public double block_time { get; set; }
        public double suspend_time { get; set; }
        public string state { get; set; }
        public string name { get; set; }
        public int  id { get; set; }
        public static int counter { get; set; }
        public process()
        { 
         
        }
        public override string ToString()
        {
            return "process_name="+name + ", " +"p_id="+ id + ", " +"exe_time="+ time;
        }
       public string tostring()
        {
            return name;
        }

    }
}
